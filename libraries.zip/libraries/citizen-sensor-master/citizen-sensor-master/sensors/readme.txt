Citizen Sensor

http://citizensensor.cc

**MQ-7 Carbon Monoxide sensor**
 > schematics, .sch, .brd of PCB
 > arduino library to be used with the Citizen Sensor MQ-7 Breakout Kit.
 > http://thesis.jmsaavedra.com/kit/mq-7-breakout-kit-maker-faire-talk/
 > www.instructables.com/id/Citizen-Sensor-MQ-7-Carbon-Monoxide-Breakout-Kit/