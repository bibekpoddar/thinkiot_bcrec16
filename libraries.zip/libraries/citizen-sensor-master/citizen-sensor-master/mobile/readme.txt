Citizen Sensor

http://citizensensor.cc

DIY environmental and air quality monitoring. Has been developed as both stationary and mobile units. 

*mobile*
 > operate as bluetooth peripheral for an Android application
 > arduino based
 > battery powered
 > updates output to LAYAR, google maps, and private social networks
 > pachube support coming

Arduino + Bluetooth antenna talks to Android phone.  Android phone beams data up to custom server.

coming: - schematics / board design
	- Android app
	- arduino compatible circuit code