/***
 *  This file defines the Sensor library version number
 *  Normally, contributors should not modify this directly
 *  as it is managed by the MySensors Bot.
 */
#ifndef Version_h
#define Version_h

#define MYSENSORS_LIBRARY_VERSION "2.0.1-beta"

#endif
